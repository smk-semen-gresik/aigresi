# Artificial-Intelligence-Workshop

Berikut saya sertakan modul beserta bahan dan dokumen pendukungan untuk melakukan coding dalam AI
